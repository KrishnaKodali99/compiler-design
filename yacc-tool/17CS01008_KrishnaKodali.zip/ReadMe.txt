READ ME
1. parser.l -> lex file which contains all the necessary tokens(terminals).
2. parser.y -> yacc file which contains the grammar.

For Compiling:
lex parser.l
yacc -d parser.y
gcc lex.yy.c y.tab.c  
