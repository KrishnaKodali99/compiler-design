					Lab Assignment-3
					
1. Lex Files Q1_1.l, Q1_2.l, Q1_3.l, Q2.l take input upon compilation.
2. Where as input for Lex file Q3.l must be given through "inputfile" which is in same folder
3. After giving the input via "inputfile" you can compile Q3.l .
